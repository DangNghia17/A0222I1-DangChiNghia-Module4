package com.codegym.a0222i1.service;

import com.codegym.a0222i1.model.ClassRoom;

import java.util.List;

public interface IClassroomService {
    List<ClassRoom> findAll();
}
