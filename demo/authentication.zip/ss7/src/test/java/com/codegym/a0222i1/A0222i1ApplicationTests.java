package com.codegym.a0222i1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A0222i1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
