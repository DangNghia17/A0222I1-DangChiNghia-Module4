package com.codegym.a0222i1.dto;

public interface StudentDTO {
    String getName();

    String getName_class();
}
